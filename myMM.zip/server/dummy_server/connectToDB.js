const {Pool} = require('pg');
const PG_URI = 'postgres://ordddiou:g5OjOyAIFxf-tsLk1uwu4ZOfbJfiCFbh@ruby.db.elephantsql.com:5432/ordddiou';

const pool = new Pool({
    connectionString: PG_URI
})

module.exports = {
    query: (text,params, callback) => {
        console.log('executed query:', text)
        return pool.query(text, params, callback)
    }
}
  